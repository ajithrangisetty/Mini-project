import { initializeApp } from "firebase/app";
import 'firebase/auth'


// const firebaseConfig = {
//   apiKey: "AIzaSyAARIFgyll92Pm5f81qHlLW4KGjpsQzxqs",
//   authDomain: "venuebooking-e87fc.firebaseapp.com",
//   projectId: "venuebooking-e87fc",
//   storageBucket: "venuebooking-e87fc.appspot.com",
//   messagingSenderId: "466731738460",
//   appId: "1:466731738460:web:deccd60d6e395f99514d99",
//   measurementId: "G-30C3QV9NQQ"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);


const firebaseConfig = {
  apiKey: "AIzaSyCvKBkpYgKdWFfSh4tuaRuFqNs6Ug1sfhg",
  authDomain: "venuebooking-90847.firebaseapp.com",
  projectId: "venuebooking-90847",
  storageBucket: "venuebooking-90847.appspot.com",
  messagingSenderId: "472710711924",
  appId: "1:472710711924:web:b281f7309f5ab825011f21",
  measurementId: "G-T3PQXN5TZG"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;




