# Prerequisites

Install NodeJS and add to path - [Download Here](https://nodejs.org/en/download/)

Next, Download zip folder of code:
   Hit on the green code<> button, download and extract the folder

# Running the code
After extracting from zip, open the folder, open command prompt and navigate to the path of the folder:


  For eg: if folder is on c drive:
  c:/... > cd VenueBookingSystem-main

Now hit : npm init

Next    : npm run dev 

Project will be started in localhost:5173.
